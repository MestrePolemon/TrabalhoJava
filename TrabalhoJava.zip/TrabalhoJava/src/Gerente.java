package TrabalhoJava.src;

public class Gerente extends Funcionario {

    public Gerente(String nome, int idade, String cpf, float bonus, float salario) {
        super(nome, idade, cpf, bonus, salario);

        

    }
    
}
